# YONO AI Phase 2 — आगे के कदम (Android)

## अभी जो जोड़ा गया
1. Kling Text-to-Video task submission
2. Kling Image-to-Video (पहली frame की public HTTPS image URL)
3. Kling task status polling
4. Anime और Manhua story prompt structure
5. Backend-only API secrets

## ₹0 में क्या संभव है?
- Expo app बनाना/चलाना और backend को locally test करना।
- Story prompt और scene planning का UI बनाना।
- Manhua panels के लिए local editing plan बनाना।
- API integration का request/response flow test करना, जहाँ provider sandbox/trial उपलब्ध हो।

## ₹0 में क्या guaranteed नहीं है?
- Kling/Leonardo/OpenAI/ElevenLabs पर unlimited real generation।
- Free permanent GPU video generation या guaranteed 720p MP4 render।
- Production hosting, database, file storage और background worker।

## अगला काम
- Backend को HTTPS hosting पर deploy करना।
- `.env` में केवल उन्हीं providers की keys डालना जिनकी billing/credits उपलब्ध हैं।
- `/api/v1/providers/status` से connection verify करना।
- Signup/login के बाद `/docs` में story, image, text-to-video, image-to-video और voice endpoints को एक-एक करके test करना।
- Generated image को HTTPS object storage पर रखना; फिर उसका URL Kling image-to-video में भेजना।
- Kling task ID से polling करके completed video URL लेना।
- अंतिम चरण में clips, voice, subtitles और music को server-side FFmpeg worker से MP4 में stitch करना।

## सुरक्षा
किसी भी API key को Android app, screenshot, GitHub या public ZIP में न रखें।
Production में HTTPS, PostgreSQL, rate limiting, job queue, storage access rules और account deletion जोड़ें।
