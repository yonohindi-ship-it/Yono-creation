import httpx
from .config import settings

class ProviderNotConfigured(Exception):
    pass

KLING_HEADERS = lambda: {
    "Authorization": f"Bearer {settings.kling_api_key}",
    "Content-Type": "application/json",
}

async def story(idea, language, style, minutes):
    if not settings.openai_api_key:
        raise ProviderNotConfigured("OpenAI disconnected: configure OPENAI_API_KEY on backend.")
    system = (
        "Return valid JSON with title, logline, characters (name, appearance, outfit, personality), "
        "and scenes (scene_number, narration, visual_prompt, camera, duration_seconds, sound_design). "
        "Keep each character's appearance and outfit consistent across every scene. "
        "Manhua style means colored comic panels and motion-comic camera directions. "
        "Anime style means cinematic full-frame animated shots, expressive acting and action choreography."
    )
    body = {
        "model": settings.openai_model,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": f"Idea: {idea}\nLanguage: {language}\nStyle: {style}\nLength: {minutes} minutes. Create a scene-by-scene production plan."}
        ],
        "temperature": 0.8,
    }
    async with httpx.AsyncClient(timeout=90) as c:
        r = await c.post("https://api.openai.com/v1/chat/completions",
                         headers={"Authorization": f"Bearer {settings.openai_api_key}"}, json=body)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]

async def image(prompt, bible):
    if not settings.leonardo_api_key:
        raise ProviderNotConfigured("Leonardo disconnected: configure LEONARDO_API_KEY.")
    body = {"prompt": f"{prompt}\nCharacter reference: {bible}", "width": 1024, "height": 576, "num_images": 1}
    if settings.leonardo_model_id:
        body["modelId"] = settings.leonardo_model_id
    async with httpx.AsyncClient(timeout=90) as c:
        r = await c.post("https://cloud.leonardo.ai/api/rest/v2/generations",
                         headers={"authorization": f"Bearer {settings.leonardo_api_key}"}, json=body)
        r.raise_for_status()
        return r.json()

def _kling_url(path):
    return settings.kling_base_url.rstrip("/") + path

async def video(prompt, duration, ratio, resolution):
    if not settings.kling_api_key:
        raise ProviderNotConfigured("Kling disconnected: configure KLING_API_KEY.")
    body = {
        "prompt": prompt,
        "settings": {
            "resolution": resolution,
            "aspect_ratio": ratio,
            "duration": duration,
            "audio": "off",
            "multi_shot": True,
        },
    }
    async with httpx.AsyncClient(timeout=90) as c:
        r = await c.post(_kling_url("/text-to-video/kling-3.0"), headers=KLING_HEADERS(), json=body)
        r.raise_for_status()
        return r.json()

async def image_to_video(image_url, prompt, duration, resolution):
    if not settings.kling_api_key:
        raise ProviderNotConfigured("Kling disconnected: configure KLING_API_KEY.")
    body = {
        "contents": [
            {"type": "prompt", "text": prompt},
            {"type": "first_frame", "url": image_url},
        ],
        "settings": {
            "resolution": resolution,
            "duration": duration,
            "audio": "off",
            "multi_shot": False,
        },
    }
    async with httpx.AsyncClient(timeout=90) as c:
        r = await c.post(_kling_url("/image-to-video/kling-3.0"), headers=KLING_HEADERS(), json=body)
        r.raise_for_status()
        return r.json()

async def task_status(task_id):
    if not settings.kling_api_key:
        raise ProviderNotConfigured("Kling disconnected: configure KLING_API_KEY.")
    async with httpx.AsyncClient(timeout=45) as c:
        r = await c.get(_kling_url(f"/tasks?task_ids={task_id}"), headers=KLING_HEADERS())
        r.raise_for_status()
        return r.json()

async def voice(text):
    if not settings.elevenlabs_api_key or not settings.elevenlabs_voice_id:
        raise ProviderNotConfigured("ElevenLabs disconnected: configure API key and voice ID.")
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{settings.elevenlabs_voice_id}"
    async with httpx.AsyncClient(timeout=90) as c:
        r = await c.post(url, headers={
            "xi-api-key": settings.elevenlabs_api_key,
            "accept": "audio/mpeg",
            "Content-Type": "application/json",
        }, json={
            "text": text,
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {"stability": 0.45, "similarity_boost": 0.8},
        })
        r.raise_for_status()
        return r.content
