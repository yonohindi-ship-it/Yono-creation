# YONO AI — Online Anime & Manhua Creator (Starter)

Runnable starter: Expo React Native Android app + FastAPI backend. Provider adapters are real API calls but remain disconnected until valid server-side keys are configured. No fake media is returned.

## Includes
- Hindi/English dark neon mobile UI
- Signup/login with JWT
- Story and scene planning (OpenAI)
- Image generation task (Leonardo)
- Text-to-video task (Kling)
- Hindi narration (ElevenLabs)
- Provider connection status
- API keys stay on backend

## Run backend
Python 3.11+
```bash
cd backend
python -m venv .venv
# activate the environment
pip install -r requirements.txt
cp .env.example .env
# set JWT_SECRET and provider keys in .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
Docs: http://localhost:8000/docs

## Run mobile
```bash
cd mobile
npm install
cp .env.example .env
# set EXPO_PUBLIC_API_URL to backend URL
npx expo start
```
For a real Android phone, use a reachable LAN/public HTTPS backend URL, not localhost.

## APK
```bash
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build -p android --profile preview
```
Cloud build needs an Expo account. APK has not been built/tested in this source package.

## API routes
GET /health; GET /api/v1/providers/status; POST /api/v1/auth/signup; POST /api/v1/auth/login;
POST /api/v1/story/generate; POST /api/v1/images/generate; POST /api/v1/videos/text-to-video; POST /api/v1/videos/image-to-video; GET /api/v1/videos/{task_id};
GET /api/v1/videos/{task_id}; POST /api/v1/voice/synthesize.

## Video styles
- Manhua motion comic: panels, narration, pans/zooms, parallax, impact frames, subtitles.
- Anime cinematic: full-frame animated shots, expressive close-ups, action beats and camera moves.

This starter creates story plans and submits provider tasks. Automated multi-clip editing, subtitle timing,
music mixing, object storage, background workers and verified 720p final export are future milestones.
Character consistency is prompt-based in this starter; robust identity consistency needs provider reference/element support.

## Cost and security
₹0 local starter use is possible, but actual OpenAI/Leonardo/Kling/ElevenLabs API calls may require paid credits.
Do not put keys in Expo public variables. SQLite is development-only; use PostgreSQL, HTTPS, rate limits,
background jobs and storage before production.


## Phase 2 changes
- Added Kling 3.0 image-to-video using a public HTTPS first-frame image URL.
- Added Kling task polling endpoint (`GET /api/v1/videos/{task_id}`).
- Updated Kling request paths to `/text-to-video/kling-3.0`, `/image-to-video/kling-3.0`
  and task query to `/tasks?task_ids=...`, following the current developer docs.
- Kling image-to-video accepts a first-frame URL; the image must be publicly reachable,
  JPEG/PNG, at least 300px each dimension, under 50MB, and within the provider aspect-ratio limits.
- Provider credentials remain backend-only. This does not make provider usage free.
